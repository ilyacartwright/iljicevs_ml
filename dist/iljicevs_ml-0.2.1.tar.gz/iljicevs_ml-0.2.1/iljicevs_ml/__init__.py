# ensemble_ml/__init__.py
from .iljicevs_model import IljicevsModel
